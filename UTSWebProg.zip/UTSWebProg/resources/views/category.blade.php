@extends('layout')
@section('content')
    <div class="p-3 mb-2 bg-warning text-dark"><h3>{{$selectedCategory}}</h3></div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Author</th>
                </tr>
            </thead>
            <tbody>
                @forelse($books as $book)
                    <tr class="bg-light">
                        <td><a href="{{url('/bookDetail').'?title='.$book->title}}", style="text-decoration: none; color:black;">{{$book->title}}</a></td>
                        <td>{{$book->author}}</td>
                   </tr>
                @empty
                    <tr class="bg-light">
                        <td class= "bg-light">No Data...</td>
                        <td class= "bg-light"></td>
                    </tr>
                @endforelse
            </tbody>
        </table>
@endsection