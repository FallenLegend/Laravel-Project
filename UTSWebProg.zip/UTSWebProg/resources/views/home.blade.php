@extends('layout')
@section('content')
    <div class="p-3 mb-2 bg-warning text-dark"><h3>Book List</h3></div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Author</th>
            </tr>
        </thead>
        <tbody>
            @foreach($books as $book)
                <tr class="bg-light">
                    <td><a href="{{url('/bookDetail').'?title='.$book->title}}", style="text-decoration: none; color:black;">{{$book->title}}</td>
                    <td>{{$book->author}}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{$books->links("pagination::bootstrap-4")}}
@endsection