@extends('layout')
@section('content')
    <div class="p-3 mb-2 bg-warning text-dark"><h2>Contact</h2></div>
    <h2>Store Address:</h2>
    Jalan Pembangunan Baru raya, <br>
    Kompleks Pertokoan Emerald Blok III/12 <br>
    Bintaro, Tangerang Selatan <br>
    Indonesia <br> <br>

    <h2>Open Daily:</h2>
    08.00 - 20.00 <br> <br>

    <h2>Contact :</h2>
    Phone : 021-08899776655 <br>
    Email : happybookstore@happy.com <br>
@endsection