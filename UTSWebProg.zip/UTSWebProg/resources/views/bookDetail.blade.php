@extends("layout")
@section('content')
    <div class="p-3 mb-2 bg-warning text-dark"><h3>Book Detail</h3></div>`
    <p>Title : {{$data[0]->title}}</p>
    <p>Author : {{$data[0]->author}}</p>
    <p>Publisher : {{$data[0]->publisher}}</p>
    <p>Year : {{$data[0]->year}}</p> 
    <p>Description :</p>
    <p>{{$data[0]->description}}</p>
@endsection