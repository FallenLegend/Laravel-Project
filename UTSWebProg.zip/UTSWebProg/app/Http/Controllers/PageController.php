<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PageController extends Controller{
    public function homePage(){
        $category = DB::select("SELECT * FROM categories");
        $book = DB::table("books")->select("book_id","title","author")->join("details","details.book_id","=","books.id")->paginate(5);
        return view("home",["categories" => $category, "books" => $book]);
    }
    public function contactPage(){
        $category = DB::select("SELECT * FROM categories");
        return view("contact", ["categories" => $category]);
    }
    public function categoryPage(Request $request){
        $data = DB::table("categories")->join("books", "categories.id", "=", "books.category_id")
        ->join("details","details.book_id","=","books.id")
        ->where("category","=", $request->query("category"))->get();
        $categories = DB::select("SELECT * FROM categories");
        $selectedCategory = $request->query("category");
        // dd($data);
        return view("category", ["categories"=>$categories, "books" => $data, "selectedCategory"=>$selectedCategory]);
    }
    public function bookDetailPage(Request $request){
        $data = DB::table("books")->join("details","details.book_id","=","books.id")
        ->where("title", "=", $request->query("title"))->get();
        $category = DB::select("SELECT category FROM categories");
        return view("bookDetail", ["categories" => $category, "data" => $data]);
    }
}