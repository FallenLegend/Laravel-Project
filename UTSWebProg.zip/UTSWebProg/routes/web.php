<?php
use Illuminate\Support\Facades\Route;

Route::get('/', [App\Http\Controllers\PageController::class, "homePage"]);
Route::get('/category', [App\Http\Controllers\PageController::class, "categoryPage"]);
Route::get('/bookDetail', [App\Http\Controllers\PageController::class, "bookDetailPage"]);
Route::get('/contact', [App\Http\Controllers\PageController::class, "contactPage"]);