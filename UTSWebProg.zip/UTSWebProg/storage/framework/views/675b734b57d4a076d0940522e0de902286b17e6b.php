
<?php $__env->startSection('content'); ?>
    <div class="p-3 mb-2 bg-warning text-dark"><h3>Book Detail</h3></div>`
    <p>Title : <?php echo e($data[0]->title); ?></p>
    <p>Author : <?php echo e($data[0]->author); ?></p>
    <p>Publisher : <?php echo e($data[0]->publisher); ?></p>
    <p>Year : <?php echo e($data[0]->year); ?></p> 
    <p>Description :</p>
    <p><?php echo e($data[0]->description); ?></p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\Xampp\htdocs\UTSWebProg\resources\views/bookDetail.blade.php ENDPATH**/ ?>