
<?php $__env->startSection('content'); ?>
    <div class="p-3 mb-2 bg-warning text-dark"><h3>Book List</h3></div>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Author</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-light">
                    <td><a href="<?php echo e(url('/bookDetail').'?title='.$book->title); ?>", style="text-decoration: none; color:black;"><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->author); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($books->links("pagination::bootstrap-4")); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\Xampp\htdocs\UTSWebProg\resources\views/home.blade.php ENDPATH**/ ?>