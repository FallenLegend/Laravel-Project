<!DOCTYPE html>
<html lang="en">
<head>
  <title>Laravel 8</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>
<body>

  <div class="container-fluid p-5 bg-primary text-white text-center">
    <h1>HAPPY BOOK STORE</h1>
  </div>
  <div class="container">
    <ul class="nav  justify-content-center">
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link  dropdown-toggle" data-bs-toggle="dropdown" href="#">Category</a>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="<?php echo e(url('/LA01/if')); ?>"><php $type = "if">If</a></li>
          <li><a class="dropdown-item" href="<?php echo e(url('/LA01/if_else')); ?>">If Else</a></li>
          <li><a class="dropdown-item" href="<?php echo e(url('/LA01/switch')); ?>">Switch</a></li>
          
<!--
  include "config.php"; // Database connection using PDO 
//$sql="SELECT name,id FROM student"; 
$sql="SELECT name,id FROM student order by name";  /* You can add order by clause to the sql statement if the names are to be displayed in alphabetical order */
echo "<select name=student value=''>Student Name</option>"; // list box select command
foreach ($dbo->query($sql) as $row){//Array or records stored in $row
  echo "<option value=$row[id]>$row[name]</option>";  /* Option values are added by looping through the array */ 
}
 echo "</select>";// Closing of list box -->
        </ul>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo e(url('/contact')); ?>">Contact</a>
      </li>
    </ul>
  </div>
  <div class="container mt-5">
    <div class="row">
      <div class="col-sm-2">
      </div>
      <div class="col-sm-8 p-3 border">
        <?php echo $__env->yieldContent('content'); ?>
      <div class="col-sm-2">
      </div>
    </div>
  </div>
  <div class="container p-1 mt-5 bg-primary text-white text-center">
    <small>&copy Happy Book Store <?php echo e(date("Y")); ?></small>
  </div>
  <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

</body>
</html><?php /**PATH D:\Program Files\Xampp\htdocs\UTSWebProg\resources\views/template.blade.php ENDPATH**/ ?>