
<?php $__env->startSection('content'); ?>
    <div class="p-3 mb-2 bg-warning text-dark"><h3><?php echo e($selectedCategory); ?></h3></div>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Title</th>
                    <th scope="col">Author</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="bg-light">
                        <td><a href="<?php echo e(url('/bookDetail').'?title='.$book->title); ?>", style="text-decoration: none; color:black;"><?php echo e($book->title); ?></a></td>
                        <td><?php echo e($book->author); ?></td>
                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="bg-light">
                        <td class= "bg-light">No Data...</td>
                        <td class= "bg-light"></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program Files\Xampp\htdocs\UTSWebProg\resources\views/category.blade.php ENDPATH**/ ?>