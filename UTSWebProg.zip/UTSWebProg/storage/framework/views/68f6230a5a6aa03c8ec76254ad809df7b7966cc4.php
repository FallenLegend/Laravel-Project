<!DOCTYPE html>
<html lang="en">
<head>
  <title>Laravel 8</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
</head>
<body>
  <div class="container-fluid p-5 bg-primary text-white text-center">
    <h1>HAPPY BOOK STORE</h1>
  </div>
  <div class="container">
    <ul class="nav  justify-content-center">
      <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a></li>
      <li class="nav-item dropdown">
        <a class="nav-link  dropdown-toggle" data-bs-toggle="dropdown" href="#">Category</a>
        <ul class="dropdown-menu">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a class="dropdown-item" href="<?php echo e(url('/category').'?category='.$category->category); ?>"><?php echo e($category->category); ?></a></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </li>
      <li class="nav-item"><a class="nav-link" href="/contact">Contact</a></li>
    </ul>
  </div>
  <div class="container mt-5">
    <div class="row">
      <div class="col-sm-2"></div>
      <div class="col-sm-8 p-3"><?php echo $__env->yieldContent('content'); ?></div>
      <div class="col-sm-2 p-3">
        <div class="p-3 mb-2 bg-warning text-dark"><h2>Category</h2></div>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a href="<?php echo e(url('/category').'?category='.$category->category); ?>", style="text-decoration:none"><?php echo e($category->category); ?></a> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
  <div class="container p-1 mt-5 bg-primary text-white text-center"><small>&copy Happy Book Store <?php echo e(date("Y")); ?></small></div>
  <script src="<?php echo e(asset('bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html><?php /**PATH D:\Program Files\Xampp\htdocs\UTSWebProg\resources\views/layout.blade.php ENDPATH**/ ?>